import React, { useState } from "react";
import { useDrag, useDrop } from "react-dnd";
import { motion } from "framer-motion";
import AICodeGenerator from "./AICodeGenerator";

const ItemTypes = {
  COMPONENT: "component",
};

// Draggable component
const DraggableComponent = ({ id, name, moveComponent }) => {
  const [, ref] = useDrag({
    type: ItemTypes.COMPONENT,
    item: { id },
  });

  return (
    <motion.div
      ref={ref}
      className="draggable-component"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      {name}
    </motion.div>
  );
};

// Drop area
const DropZone = ({ components, moveComponent }) => {
  const [, ref] = useDrop({
    accept: ItemTypes.COMPONENT,
    drop: (item) => moveComponent(item.id),
  });

  return (
    <div ref={ref} className="drop-zone">
      {components.map((component, index) => (
        <DraggableComponent
          key={index}
          id={index}
          name={component}
          moveComponent={moveComponent}
        />
      ))}
    </div>
  );
};

// Main Drag-and-Drop Editor
const DragDropEditor = () => {
  const [components, setComponents] = useState([
    "Hero Section",
    "Pricing Table",
    "Contact Form",
  ]);

  const addGeneratedSection = async (code) => {
    setComponents((prevComponents) => {
      const newLayout = [...prevComponents, code];

      // Save to Firebase
      saveLayout(newLayout, "your-crm-id");

      return newLayout;
    });
  };

  const moveComponent = (id) => {
    setComponents((prevComponents) => {
      const newComponents = [...prevComponents];
      const movedComponent = newComponents.splice(id, 1)[0];
      newComponents.push(movedComponent);
      return newComponents;
    });
  };

  return (
    <div className="editor-container">
      <h2>Drag and Drop CRM Editor</h2>
      <AICodeGenerator addGeneratedSection={addGeneratedSection} />
      <DropZone components={components} moveComponent={moveComponent} />
    </div>
  );
};

export default DragDropEditor;