
import React, { useState, useEffect } from "react";
import { db, collection, addDoc, getDocs, doc, updateDoc } from "../firebase";

const SaveLoadEditor = ({ components, userId, crmId, setComponents }) => {
  const [savedLayouts, setSavedLayouts] = useState([]);

  const loadLayout = async (crmId) => {
    if (!crmId) return alert("CRM ID is missing!");

    try {
      const querySnapshot = await getDocs(collection(db, "CRM_Layouts"));
      const layouts = querySnapshot.docs.map(doc => doc.data());

      if (layouts.length > 0) {
        setComponents(layouts[0].layout);
      }
    } catch (error) {
      console.error("Error loading layout:", error);
    }
  };

  const saveLayout = async (components, crmId) => {
    if (!crmId) return alert("CRM ID is missing!");

    try {
      const crmRef = doc(db, "CRM_Layouts", crmId);

      // Check if CRM layout already exists
      const existingLayout = await getDocs(collection(db, "CRM_Layouts"));
      const layouts = existingLayout.docs.map(doc => doc.data());

      if (layouts.length > 0) {
        // If layout exists, update it
        await updateDoc(crmRef, { layout: components });
      } else {
        // Otherwise, create a new layout entry
        await addDoc(collection(db, "CRM_Layouts"), {
          crmId,
          layout: components,
          createdAt: new Date(),
        });
      }

      alert("Layout saved successfully!");
    } catch (error) {
      console.error("Error saving layout:", error);
    }
  };

  // Load layouts from Firebase
  useEffect(() => {
    const loadLayouts = async () => {
      try {
        const layoutsQuery = query(
          collection(db, "CRM_Layouts"),
          where("ownerId", "==", userId)
        );
        const querySnapshot = await getDocs(layoutsQuery);
        const layouts = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        setSavedLayouts(layouts);
      } catch (error) {
        console.error("Error loading layouts:", error);
      }
    };

    if (userId) {
      loadLayouts();
    }
    
    // Load initial layout
    loadLayout("your-crm-id");
  }, [userId]);

  return (
    <div className="save-load-editor">
      <button onClick={() => saveLayout(components, "your-crm-id")}>Save Layout</button>
      <button onClick={() => loadLayout("your-crm-id")}>Load Layout</button>
      <h3>Saved Layouts</h3>
      <div className="saved-layouts">
        {savedLayouts.map((layout) => (
          <div key={layout.id} className="layout-item">
            <span>Created: {new Date(layout.createdAt).toLocaleDateString()}</span>
            <ul>
              {layout.layout.map((component, index) => (
                <li key={index}>{component}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SaveLoadEditor;
