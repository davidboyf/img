
import React, { useState } from "react";
import axios from "axios";

const ZoomMeetings = () => {
  const [meeting, setMeeting] = useState({ topic: "", startTime: "", duration: 30 });

  const createMeeting = async () => {
    const response = await axios.post("/api/create-zoom-meeting", meeting);
    alert(`Meeting created! Join here: ${response.data.join_url}`);
  };

  return (
    <div className="zoom-meetings">
      <h3>Schedule a Zoom Meeting</h3>
      <div className="meeting-form">
        <input 
          type="text" 
          placeholder="Topic" 
          onChange={(e) => setMeeting({ ...meeting, topic: e.target.value })} 
        />
        <input 
          type="datetime-local" 
          onChange={(e) => setMeeting({ ...meeting, startTime: e.target.value })} 
        />
        <input 
          type="number" 
          placeholder="Duration (mins)" 
          onChange={(e) => setMeeting({ ...meeting, duration: e.target.value })} 
        />
        <button onClick={createMeeting}>Create Meeting</button>
      </div>
    </div>
  );
};

export default ZoomMeetings;
