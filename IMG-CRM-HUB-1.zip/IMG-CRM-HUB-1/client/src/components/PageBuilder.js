import React from "react";

const PageBuilder = () => {
  return (
    <div className="p-10 text-white">
      <h2 className="text-3xl font-bold mb-5">Webflow-Style CRM Editor</h2>

      <div className="flex">
        <div className="w-1/4 bg-gray-900 p-5 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-3">Elements</h3>
          <button className="w-full py-2 px-4 bg-blue-600 rounded hover:bg-blue-700">Heading</button>
          <button className="w-full py-2 px-4 bg-blue-600 rounded hover:bg-blue-700 mt-2">Paragraph</button>
          <button className="w-full py-2 px-4 bg-blue-600 rounded hover:bg-blue-700 mt-2">Image</button>
          <button className="w-full py-2 px-4 bg-blue-600 rounded hover:bg-blue-700 mt-2">Button</button>
        </div>

        <div className="w-3/4 bg-gray-800 p-5 ml-5 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold">Canvas</h3>
          <p className="text-gray-400">Drag and drop elements here.</p>
        </div>
      </div>
    </div>
  );
};

export default PageBuilder;