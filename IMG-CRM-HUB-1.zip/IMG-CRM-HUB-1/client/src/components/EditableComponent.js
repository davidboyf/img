
import React, { useState } from "react";

const EditableComponent = ({ text, onSave }) => {
  const [content, setContent] = useState(text);
  const [isEditing, setIsEditing] = useState(false);

  const handleBlur = () => {
    setIsEditing(false);
    onSave(content);
  };

  return isEditing ? (
    <input
      type="text"
      value={content}
      onChange={(e) => setContent(e.target.value)}
      onBlur={handleBlur}
      autoFocus
    />
  ) : (
    <div onClick={() => setIsEditing(true)}>{content}</div>
  );
};

export default EditableComponent;
