
import React, { useState } from "react";
import { db, collection, addDoc, getDocs } from "../firebase";

const CMSDashboard = ({ crmId }) => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const addBlogPost = async () => {
    await addDoc(collection(db, "CMS_Content"), {
      crmId,
      collectionName: "BlogPosts",
      fields: { title, content, publishedAt: new Date() },
    });
    alert("Blog post added!");
  };

  return (
    <div className="cms-dashboard">
      <h3>CMS: Blog Posts</h3>
      <input type="text" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
      <textarea placeholder="Content" value={content} onChange={(e) => setContent(e.target.value)} />
      <button onClick={addBlogPost}>Add Blog Post</button>
    </div>
  );
};

export default CMSDashboard;
