
import { initializeApp } from "firebase/app";
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut } from "firebase/auth";
import { getFirestore, onSnapshot, collection, doc, getDoc, setDoc, addDoc, getDocs } from "firebase/firestore";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyDPTcfpDpCkDAcg6heButYTAa8b8sQjJZM",
  authDomain: "first-crm-53c32.firebaseapp.com",
  projectId: "first-crm-53c32",
  storageBucket: "first-crm-53c32.firebasestorage.app",
  messagingSenderId: "389241732891",
  appId: "1:389241732891:web:8b62d8d7b4813b655e5dbe",
  measurementId: "G-P3P6VCR089"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();

export {
  auth,
  db,
  provider,
  analytics,
  signInWithPopup,
  signOut,
  GoogleAuthProvider,
  onSnapshot,
  collection,
  doc,
  getDoc,
  setDoc,
  addDoc,
  getDocs
};
