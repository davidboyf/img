
import React, { useState } from 'react';
import axios from 'axios';

const MeetingBooking = () => {
  const [meeting, setMeeting] = useState({
    title: '',
    startTime: '',
    duration: 30
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/schedule-meeting', meeting);
      alert(`Meeting scheduled! Calendar link: ${response.data.eventLink}`);
    } catch (error) {
      alert('Error scheduling meeting: ' + error.message);
    }
  };

  return (
    <div className="meeting-booking">
      <h3>Schedule a Meeting</h3>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Meeting Title"
          value={meeting.title}
          onChange={(e) => setMeeting({ ...meeting, title: e.target.value })}
          required
        />
        <input
          type="datetime-local"
          value={meeting.startTime}
          onChange={(e) => setMeeting({ ...meeting, startTime: e.target.value })}
          required
        />
        <input
          type="number"
          placeholder="Duration (minutes)"
          value={meeting.duration}
          onChange={(e) => setMeeting({ ...meeting, duration: parseInt(e.target.value) })}
          required
        />
        <button type="submit">Schedule Meeting</button>
      </form>
    </div>
  );
};

export default MeetingBooking;
