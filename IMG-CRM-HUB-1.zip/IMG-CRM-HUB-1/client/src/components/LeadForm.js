
import React, { useState } from "react";
import { db, collection, addDoc } from "../firebase";

const LeadForm = () => {
  const [lead, setLead] = useState({ name: "", email: "", message: "", source: "direct" });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    if (!lead.name.trim()) newErrors.name = "Name is required";
    if (!lead.email.trim()) newErrors.email = "Email is required";
    if (!/\S+@\S+\.\S+/.test(lead.email)) newErrors.email = "Invalid email format";
    if (!lead.message.trim()) newErrors.message = "Message is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const submitLead = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      await addDoc(collection(db, "Leads"), {
        ...lead,
        createdAt: new Date().toISOString(),
        status: "new"
      });
      setLead({ name: "", email: "", message: "", source: "direct" });
      alert("Thank you! We'll be in touch soon.");
    } catch (error) {
      alert("Error submitting form: " + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="lead-form-container">
      <h3>Contact Us</h3>
      <form onSubmit={submitLead} className="lead-form">
        <div className="form-group">
          <input
            type="text"
            placeholder="Name"
            value={lead.name}
            onChange={(e) => setLead({ ...lead, name: e.target.value })}
            className={errors.name ? "error" : ""}
          />
          {errors.name && <span className="error-message">{errors.name}</span>}
        </div>

        <div className="form-group">
          <input
            type="email"
            placeholder="Email"
            value={lead.email}
            onChange={(e) => setLead({ ...lead, email: e.target.value })}
            className={errors.email ? "error" : ""}
          />
          {errors.email && <span className="error-message">{errors.email}</span>}
        </div>

        <div className="form-group">
          <textarea
            placeholder="How can we help you?"
            value={lead.message}
            onChange={(e) => setLead({ ...lead, message: e.target.value })}
            className={errors.message ? "error" : ""}
            rows="4"
          />
          {errors.message && <span className="error-message">{errors.message}</span>}
        </div>

        <div className="form-group">
          <select
            value={lead.source}
            onChange={(e) => setLead({ ...lead, source: e.target.value })}
          >
            <option value="direct">Direct</option>
            <option value="referral">Referral</option>
            <option value="social">Social Media</option>
            <option value="search">Search Engine</option>
          </select>
        </div>

        <button 
          type="submit" 
          className="submit-button"
          disabled={isSubmitting}
        >
          {isSubmitting ? "Submitting..." : "Send Message"}
        </button>
      </form>
    </div>
  );
};

export default LeadForm;
