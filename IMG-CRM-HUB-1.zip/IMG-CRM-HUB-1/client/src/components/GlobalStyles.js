
import React, { useState } from "react";

const GlobalStyles = ({ applyStyles }) => {
  const [styles, setStyles] = useState({
    primaryColor: "#007bff",
    secondaryColor: "#6c757d",
    fontFamily: "Arial, sans-serif",
    border: "1px solid #ddd",
    boxShadow: "none",
    borderRadius: "5px",
  });

  const updateStyles = (e) => {
    setStyles({ ...styles, [e.target.name]: e.target.value });
    applyStyles(styles);
  };

  return (
    <div className="global-styles">
      <label>Primary Color</label>
      <input type="color" name="primaryColor" value={styles.primaryColor} onChange={updateStyles} />

      <label>Border</label>
      <select name="border" value={styles.border} onChange={updateStyles}>
        <option value="none">None</option>
        <option value="1px solid #ddd">Thin Border</option>
        <option value="2px solid black">Thick Border</option>
      </select>

      <label>Box Shadow</label>
      <select name="boxShadow" value={styles.boxShadow} onChange={updateStyles}>
        <option value="none">None</option>
        <option value="0px 4px 6px rgba(0, 0, 0, 0.1)">Soft Shadow</option>
        <option value="0px 6px 10px rgba(0, 0, 0, 0.2)">Strong Shadow</option>
      </select>

      <label>Border Radius</label>
      <input type="number" name="borderRadius" value={styles.borderRadius} onChange={updateStyles} /> px
    </div>
  );
};

export default GlobalStyles;
