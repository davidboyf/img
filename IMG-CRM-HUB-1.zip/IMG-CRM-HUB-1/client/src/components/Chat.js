
import React, { useState, useEffect } from "react";
import { db, collection, addDoc, getDocs, onSnapshot } from "../firebase";

const Chat = ({ userId }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "Chats"), (snapshot) => {
      setMessages(snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id
      })).sort((a, b) => a.timestamp - b.timestamp));
    });
    return () => unsubscribe();
  }, []);

  const sendMessage = async () => {
    if (newMessage.trim()) {
      await addDoc(collection(db, "Chats"), {
        userId,
        message: newMessage,
        timestamp: new Date().getTime()
      });
      setNewMessage("");
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  };

  return (
    <div className="chat-container">
      <h3>Live Chat</h3>
      <div className="messages-list">
        {messages.map((msg) => (
          <div 
            key={msg.id}
            className={`message ${msg.userId === userId ? 'message-sent' : 'message-received'}`}
          >
            <span className="message-user">{msg.userId}</span>
            <span className="message-text">{msg.message}</span>
          </div>
        ))}
      </div>
      <div className="message-input">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type a message..."
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
};

export default Chat;
