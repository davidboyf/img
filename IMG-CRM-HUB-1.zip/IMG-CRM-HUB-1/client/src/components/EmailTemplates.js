
import React, { useState } from "react";
import axios from "axios";

const EmailTemplates = () => {
  const [email, setEmail] = useState({ to: "", subject: "", message: "" });

  const sendEmail = async () => {
    try {
      await axios.post("http://0.0.0.0:5000/send-email", email);
      alert("Email Sent!");
    } catch (error) {
      console.error("Error sending email:", error);
    }
  };

  return (
    <div>
      <h3>Email Templates</h3>
      <input type="email" placeholder="Recipient Email" onChange={(e) => setEmail({ ...email, to: e.target.value })} />
      <input type="text" placeholder="Subject" onChange={(e) => setEmail({ ...email, subject: e.target.value })} />
      <textarea placeholder="Message" onChange={(e) => setEmail({ ...email, message: e.target.value })} />
      <button onClick={sendEmail}>Send Email</button>
    </div>
  );
};

export default EmailTemplates;
