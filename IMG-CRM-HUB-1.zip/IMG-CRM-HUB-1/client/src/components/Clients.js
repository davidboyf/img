
import React, { useState, useEffect } from "react";
import { db, collection, addDoc, getDocs } from "../firebase";

const Clients = () => {
  const [clients, setClients] = useState([]);
  const [newClient, setNewClient] = useState({ 
    name: "", 
    email: "", 
    phone: "", 
    status: "Lead", 
    notes: "" 
  });

  useEffect(() => {
    const fetchClients = async () => {
      const querySnapshot = await getDocs(collection(db, "Clients"));
      setClients(querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    };
    fetchClients();
  }, []);

  const addClient = async (e) => {
    e.preventDefault();
    if (!newClient.name || !newClient.email) {
      alert("Name and email are required!");
      return;
    }
    try {
      await addDoc(collection(db, "Clients"), {
        ...newClient,
        createdAt: new Date().toISOString()
      });
      setNewClient({ name: "", email: "", phone: "", status: "Lead", notes: "" });
      alert("Client added successfully!");
    } catch (error) {
      alert("Error adding client: " + error.message);
    }
  };

  return (
    <div className="clients-container">
      <div className="add-client-section">
        <h3>Add New Client</h3>
        <form onSubmit={addClient} className="client-form">
          <div className="form-group">
            <input
              type="text"
              placeholder="Name"
              value={newClient.name}
              onChange={(e) => setNewClient({ ...newClient, name: e.target.value })}
            />
          </div>
          <div className="form-group">
            <input
              type="email"
              placeholder="Email"
              value={newClient.email}
              onChange={(e) => setNewClient({ ...newClient, email: e.target.value })}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              placeholder="Phone"
              value={newClient.phone}
              onChange={(e) => setNewClient({ ...newClient, phone: e.target.value })}
            />
          </div>
          <div className="form-group">
            <select
              value={newClient.status}
              onChange={(e) => setNewClient({ ...newClient, status: e.target.value })}
            >
              <option value="Lead">Lead</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
          <div className="form-group">
            <textarea
              placeholder="Notes"
              value={newClient.notes}
              onChange={(e) => setNewClient({ ...newClient, notes: e.target.value })}
            />
          </div>
          <button type="submit" className="submit-button">Add Client</button>
        </form>
      </div>

      <div className="clients-list-section">
        <h4>Client List</h4>
        <div className="clients-grid">
          {clients.map((client) => (
            <div key={client.id} className="client-card">
              <h4>{client.name}</h4>
              <p><strong>Email:</strong> {client.email}</p>
              <p><strong>Phone:</strong> {client.phone || 'N/A'}</p>
              <p><strong>Status:</strong> <span className={`status-${client.status.toLowerCase()}`}>{client.status}</span></p>
              {client.notes && <p><strong>Notes:</strong> {client.notes}</p>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Clients;
