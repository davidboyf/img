import React, { useState } from "react";
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import PageBuilder from "./components/PageBuilder";

function App() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [darkMode, setDarkMode] = useState(true);

  return (
    <DndProvider backend={HTML5Backend}>
      <div className={`${darkMode ? "bg-gray-900 text-white" : "bg-white text-black"} flex h-screen`}>
        <Sidebar setActiveTab={setActiveTab} />
        <div className="flex-1 p-10">
          <button className="mb-5 px-4 py-2 bg-gray-700 text-white rounded" onClick={() => setDarkMode(!darkMode)}>
            {darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
          </button>

          {activeTab === "dashboard" && <Dashboard />}
          {activeTab === "builder" && <PageBuilder />}
        </div>
      </div>
    </DndProvider>
  );
}

export default App;