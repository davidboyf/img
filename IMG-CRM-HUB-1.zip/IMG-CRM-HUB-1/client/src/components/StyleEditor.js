
import React, { useState } from "react";

const StyleEditor = ({ selectedElement, updateStyle }) => {
  const [styles, setStyles] = useState({
    color: "#000000",
    backgroundColor: "#ffffff",
    fontSize: "16px",
  });

  const handleChange = (e) => {
    setStyles({ ...styles, [e.target.name]: e.target.value });
    updateStyle(styles);
  };

  return (
    <div className="style-editor">
      <h3>Style Editor</h3>
      <label>Text Color</label>
      <input type="color" name="color" value={styles.color} onChange={handleChange} />

      <label>Background Color</label>
      <input type="color" name="backgroundColor" value={styles.backgroundColor} onChange={handleChange} />

      <label>Font Size</label>
      <input type="number" name="fontSize" value={styles.fontSize} onChange={handleChange} />
    </div>
  );
};

export default StyleEditor;
