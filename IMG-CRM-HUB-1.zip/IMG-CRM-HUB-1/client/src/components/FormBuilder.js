import React, { useState } from "react";

const FormBuilder = () => {
  const [fields, setFields] = useState([{ label: "Your Name", type: "text" }]);

  const addField = () => {
    setFields([...fields, { label: "New Field", type: "text" }]);
  };

  return (
    <div className="form-builder">
      <h3>Form Builder</h3>
      {fields.map((field, index) => (
        <div key={index}>
          <label>{field.label}</label>
          <input type={field.type} />
        </div>
      ))}
      <button onClick={addField}>Add Field</button>
    </div>
  );
};

export default FormBuilder;