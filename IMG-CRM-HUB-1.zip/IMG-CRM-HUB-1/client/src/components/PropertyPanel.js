
import React, { useState } from "react";

const PropertyPanel = ({ selectedSection, onUpdate }) => {
  const [styles, setStyles] = useState({
    padding: "10px",
    margin: "5px",
    backgroundColor: "#ffffff",
    fontSize: "14px",
    textAlign: "left",
    borderRadius: "0px",
    boxShadow: "none",
    border: "none",
  });

  const handleChange = (property, value) => {
    setStyles((prev) => ({ ...prev, [property]: value }));
    onUpdate(styles);
  };

  return (
    <div style={{
      position: "fixed",
      top: "20px",
      right: "20px",
      background: "#fff",
      padding: "15px",
      borderRadius: "10px",
      boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
      width: "250px"
    }}>
      <h4>Section Styles</h4>

      <label>Padding</label>
      <input type="range" min="0" max="50" onChange={(e) => handleChange("padding", `${e.target.value}px`)} />

      <label>Margin</label>
      <input type="range" min="0" max="50" onChange={(e) => handleChange("margin", `${e.target.value}px`)} />

      <label>Font Size</label>
      <input type="range" min="12" max="40" onChange={(e) => handleChange("fontSize", `${e.target.value}px`)} />

      <label>Text Align</label>
      <select onChange={(e) => handleChange("textAlign", e.target.value)}>
        <option value="left">Left</option>
        <option value="center">Center</option>
        <option value="right">Right</option>
      </select>

      <label>Border Radius</label>
      <input type="range" min="0" max="50" onChange={(e) => handleChange("borderRadius", `${e.target.value}px`)} />

      <label>Box Shadow</label>
      <select onChange={(e) => handleChange("boxShadow", e.target.value)}>
        <option value="none">None</option>
        <option value="0px 4px 10px rgba(0,0,0,0.1)">Light</option>
        <option value="0px 6px 15px rgba(0,0,0,0.2)">Medium</option>
        <option value="0px 8px 20px rgba(0,0,0,0.3)">Heavy</option>
      </select>

      <label>Border</label>
      <input type="color" onChange={(e) => handleChange("border", `2px solid ${e.target.value}`)} />
    </div>
  );
};

export default PropertyPanel;
