
module.exports = {
  plugins: {
    'tailwindcss': {},
    'autoprefixer': {},
    '@tailwindcss/typography': {},
  },
}
