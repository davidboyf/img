
import React, { useState, useEffect } from "react";
import { auth, signInWithPopup, GoogleAuthProvider, signOut, db } from "../firebase";
import { doc, getDoc } from "firebase/firestore";

const getUserRole = async (userId) => {
  const userRef = doc(db, "Users", userId);
  const userSnap = await getDoc(userRef);
  return userSnap.exists() ? userSnap.data().role : "viewer";
};

const Auth = () => {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState("viewer");

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      setUser(user);
      if (user) {
        const role = await getUserRole(user.uid);
        setUserRole(role);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
  };

  const handleLogout = async () => {
    await signOut(auth);
  };

  return (
    <div>
      {user ? (
        <div>
          <p>Welcome, {user.displayName}!</p>
          <p>Role: {userRole}</p>
          <button onClick={handleLogout}>Logout</button>
        </div>
      ) : (
        <button onClick={handleLogin}>Login with Google</button>
      )}
    </div>
  );
};

export default Auth;
