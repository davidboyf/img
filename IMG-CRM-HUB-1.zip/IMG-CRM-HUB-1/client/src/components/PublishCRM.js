
import React, { useState } from "react";
import axios from "axios";

const PublishCRM = () => {
  const [clientName, setClientName] = useState("");
  const [subdomain, setSubdomain] = useState("");
  const [customDomain, setCustomDomain] = useState("");

  const createSubdomain = async () => {
    try {
      const response = await axios.post("/create-subdomain", { clientName });
      setSubdomain(response.data.subdomain);
    } catch (error) {
      alert("Error creating subdomain: " + error.message);
    }
  };

  const connectDomain = async () => {
    try {
      await axios.post("/connect-domain", { clientName, customDomain });
      alert(`Domain connected: ${customDomain}`);
    } catch (error) {
      alert("Error connecting domain: " + error.message);
    }
  };

  return (
    <div className="publish-crm">
      <h3>Publish Your CRM</h3>
      <div className="form-group">
        <input 
          type="text" 
          placeholder="Client Name" 
          value={clientName}
          onChange={(e) => setClientName(e.target.value)} 
        />
        <button onClick={createSubdomain}>Create Subdomain</button>
      </div>
      {subdomain && <p className="success-message">Your CRM is live at: {subdomain}</p>}

      <h3>Connect Custom Domain</h3>
      <div className="form-group">
        <input 
          type="text" 
          placeholder="yourdomain.com" 
          value={customDomain}
          onChange={(e) => setCustomDomain(e.target.value)} 
        />
        <button onClick={connectDomain}>Connect Domain</button>
      </div>
    </div>
  );
};

export default PublishCRM;
