import React, { useEffect, useRef } from "react";
import gsap from "gsap";

const GSAPAnimations = ({ children, animationType }) => {
  const sectionRef = useRef(null);

  useEffect(() => {
    if (animationType === "fade-in") {
      gsap.fromTo(sectionRef.current, 
        { opacity: 0, y: 10 }, 
        { opacity: 1, y: 0, duration: 0.4, ease: "power2.out" }
      );
    } else if (animationType === "slide-in") {
      gsap.fromTo(sectionRef.current, 
        { x: -30, opacity: 0 }, 
        { x: 0, opacity: 1, duration: 0.5, ease: "power2.inOut" }
      );
    } else if (animationType === "scale-up") {
      gsap.fromTo(sectionRef.current, 
        { scale: 0.95, opacity: 0 }, 
        { scale: 1, opacity: 1, duration: 0.4, ease: "back.out(1.2)" }
      );
    }
  }, [animationType]);

  return <div ref={sectionRef}>{children}</div>;
};

export default GSAPAnimations;