
import React from "react";
import Clients from "./Clients";
import LeadForm from "./LeadForm";
import EmailTemplates from "./EmailTemplates";
import MeetingBooking from "./MeetingBooking";
import Chat from "./Chat";
import SocialScheduler from "./SocialScheduler";

const BusinessHub = () => {
  return (
    <div className="business-hub">
      <h2>Business Hub</h2>

      <div className="hub-grid">
        <div className="section clients-section">
          <Clients />
        </div>

        <div className="section lead-section">
          <LeadForm />
        </div>

        <div className="section meeting-section">
          <MeetingBooking />
        </div>

        <div className="section email-section">
          <EmailTemplates />
        </div>

        <div className="section social-section">
          <SocialScheduler />
        </div>

        <div className="section chat-section">
          <Chat userId="current-user-id" />
        </div>
      </div>
    </div>
  );
};

export default BusinessHub;
