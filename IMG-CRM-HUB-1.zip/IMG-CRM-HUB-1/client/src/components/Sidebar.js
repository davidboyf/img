
import React from "react";

const Sidebar = ({ setActiveTab }) => {
  return (
    <div className="w-64 h-screen bg-gray-900 text-white flex flex-col shadow-lg">
      <h2 className="text-xl font-bold p-5">IMG CRM HUB</h2>
      <nav className="flex flex-col space-y-2 p-3">
        <button className="flex items-center space-x-2 p-2 hover:bg-gray-800 rounded" onClick={() => setActiveTab("dashboard")}>
          <span>🏠</span> <span>Dashboard</span>
        </button>
        <button className="flex items-center space-x-2 p-2 hover:bg-gray-800 rounded" onClick={() => setActiveTab("builder")}>
          <span>🛠️</span> <span>Page Builder</span>
        </button>
        <button className="flex items-center space-x-2 p-2 hover:bg-gray-800 rounded" onClick={() => setActiveTab("clients")}>
          <span>👥</span> <span>Clients</span>
        </button>
        <button className="flex items-center space-x-2 p-2 hover:bg-gray-800 rounded" onClick={() => setActiveTab("settings")}>
          <span>⚙️</span> <span>Settings</span>
        </button>
      </nav>
    </div>
  );
};

export default Sidebar;
