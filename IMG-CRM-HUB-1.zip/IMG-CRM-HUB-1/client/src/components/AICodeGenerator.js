
import React, { useState } from "react";
import axios from "axios";

const AICodeGenerator = ({ addGeneratedSection }) => {
  const [userInput, setUserInput] = useState("");
  const [loading, setLoading] = useState(false);

  const generateCode = async () => {
    if (!userInput.trim()) return;
    setLoading(true);

    try {
      const response = await axios.post("http://0.0.0.0:5000/generate-section", {
        userPrompt: userInput,
      });

      // Insert AI-generated section into layout
      addGeneratedSection(response.data.code);
      setUserInput("");
    } catch (error) {
      console.error("Error generating code:", error);
    }

    setLoading(false);
  };

  return (
    <div className="ai-generator">
      <input
        type="text"
        placeholder="Describe a section (e.g., 'Create a responsive pricing table')"
        value={userInput}
        onChange={(e) => setUserInput(e.target.value)}
      />
      <button onClick={generateCode} disabled={loading}>
        {loading ? "Generating..." : "Generate Section"}
      </button>
    </div>
  );
};

export default AICodeGenerator;
