
import React, { useState } from "react";
import { motion } from "framer-motion";

const AnimationControls = ({ children }) => {
  const [animation, setAnimation] = useState("fadeIn");

  const animations = {
    fadeIn: { opacity: 0, y: 20, transition: { duration: 0.5 } },
    scaleUp: { scale: 0.8, transition: { duration: 0.5 } },
    slideIn: { x: -50, opacity: 0, transition: { duration: 0.5 } },
  };

  return (
    <div>
      <select onChange={(e) => setAnimation(e.target.value)}>
        <option value="fadeIn">Fade In</option>
        <option value="scaleUp">Scale Up</option>
        <option value="slideIn">Slide In</option>
      </select>
      <motion.div initial={animations[animation]} animate={{ opacity: 1, x: 0, scale: 1 }}>
        {children}
      </motion.div>
    </div>
  );
};

export default AnimationControls;
