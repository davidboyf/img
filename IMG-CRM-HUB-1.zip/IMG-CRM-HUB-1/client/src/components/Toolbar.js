
import React from "react";

const Toolbar = ({ addElement }) => {
  return (
    <div className="toolbar">
      <h3>Elements</h3>
      <button onClick={() => addElement("Heading")}>Heading</button>
      <button onClick={() => addElement("Paragraph")}>Paragraph</button>
      <button onClick={() => addElement("Image")}>Image</button>
      <button onClick={() => addElement("Button")}>Button</button>
      <button onClick={() => addElement("Video")}>Video</button>
      <button onClick={() => addElement("Form")}>Form</button>
    </div>
  );
};

export default Toolbar;
