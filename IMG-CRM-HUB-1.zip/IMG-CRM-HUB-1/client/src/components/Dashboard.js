
import React, { useEffect, useState } from "react";

const Dashboard = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    console.log("This will break");
  }, []);

  return (
    <div className="p-10 text-white">
      <h2 className="text-3xl font-bold mb-5">Welcome to IMG CRM HUB</h2>
      <p className="text-gray-400">Overview of your business & projects.</p>

      <div className="grid grid-cols-3 gap-5 mt-5">
        <div className="bg-gray-800 p-5 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold">Active Projects</h3>
          <p className="text-2xl font-bold mt-2">12</p>
        </div>
        <div className="bg-gray-800 p-5 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold">Pending Tasks</h3>
          <p className="text-2xl font-bold mt-2">5 Due</p>
        </div>
        <div className="bg-gray-800 p-5 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold">Upcoming Meetings</h3>
          <p className="text-2xl font-bold mt-2">3 Scheduled</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
