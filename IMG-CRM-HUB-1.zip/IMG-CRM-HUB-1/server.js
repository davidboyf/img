const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();
const { initializeApp, cert } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const path = require('path');
const axios = require("axios");
const { v4: uuidv4 } = require("uuid"); 
const { MongoClient } = require('mongodb'); 
const { google } = require("googleapis");

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;

// Initialize Firebase Admin
const admin = require('firebase-admin');
let db;

try {
  if (!admin.apps.length) {
    if (process.env.FIREBASE_ADMIN_CONFIG) {
      admin.initializeApp({
        credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_ADMIN_CONFIG))
      });
    } else {
      throw new Error('Firebase credentials not found');
    }
  }
  db = admin.firestore();
} catch (error) {
  console.error('Firebase initialization failed:', error.message);
}

app.use(cors());
app.use(express.json());

// Serve static files from React app
app.use(express.static(path.join(__dirname, 'client/build')));

// API routes go here
const mongoose = require("mongoose");
const MONGODB_URI = process.env.MONGODB_URI || "";

let client;
if (MONGODB_URI) {
  mongoose.connect(MONGODB_URI)
    .then(() => console.log('MongoDB connected successfully'))
    .catch(err => console.error('MongoDB connection error:', err));

  client = new MongoClient(MONGODB_URI);
  console.log('MongoDB client initialized');
} else {
  console.log('MongoDB URI not found - running without MongoDB');
}

// Mailchimp API integration
app.post("/mailchimp-subscribe", async (req, res) => {
  const { email } = req.body;
  const DATACENTER = process.env.MAILCHIMP_API_KEY.split('-')[1];

  try {
    const response = await axios.post(`https://${DATACENTER}.api.mailchimp.com/3.0/lists/${process.env.MAILCHIMP_LIST_ID}/members`, {
      email_address: email,
      status: "subscribed",
    }, {
      headers: {
        Authorization: `Basic ${Buffer.from(`anystring:${process.env.MAILCHIMP_API_KEY}`).toString('base64')}`,
      },
    });

    res.json({ message: "Email subscribed!", response: response.data });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Zoom meeting integration
app.post("/api/create-zoom-meeting", async (req, res) => {
  const { topic, startTime, duration } = req.body;

  try {
    const response = await axios.post('https://api.zoom.us/v2/users/me/meetings', {
      topic,
      start_time: startTime,
      duration,
      type: 2
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.ZOOM_JWT_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });

    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Zapier webhook integration
app.post("/zapier-webhook", async (req, res) => {
  const { event, data } = req.body;

  try {
    const response = await axios.post(process.env.ZAPIER_WEBHOOK_URL, {
      event,
      data,
    });

    res.json({ message: "Zapier Webhook Triggered", response: response.data });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// TikTok Video Scheduler
app.post("/schedule-tiktok", async (req, res) => {
  const { videoUrl, caption, scheduledTime } = req.body;

  try {
    const response = await axios.post(
      `https://open.tiktokapis.com/v2/video/upload`,
      {
        video_url: videoUrl,
        caption: caption,
        scheduled_publish_time: scheduledTime,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.TIKTOK_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    res.json({ message: "TikTok video scheduled!", response: response.data });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Instagram Post Scheduler
app.post("/schedule-instagram", async (req, res) => {
  const { imageUrl, caption, scheduledTime } = req.body;

  try {
    const response = await axios.post(
      `https://graph.facebook.com/v18.0/YOUR_INSTAGRAM_BUSINESS_ID/media`,
      {
        image_url: imageUrl,
        caption: caption,
        access_token: process.env.INSTAGRAM_API_KEY,
        scheduled_publish_time: scheduledTime,
      }
    );

    res.json({ message: "Instagram post scheduled!", response: response.data });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Brevo Email Integration
app.post("/send-email", async (req, res) => {
  const { recipients, subject, message } = req.body;

  try {
    const response = await axios.post(
      "https://api.brevo.com/v3/smtp/email",
      {
        sender: { name: "Your Business", email: "yourbusiness@yourhub.com" },
        to: recipients.map(email => ({ email })),
        subject,
        htmlContent: message,
      },
      {
        headers: {
          "api-key": process.env.BREVO_API_KEY,
          "Content-Type": "application/json",
        },
      }
    );

    res.json({ message: "Email sent successfully!", response: response.data });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/schedule-meeting", async (req, res) => {
  const { title, startTime, duration } = req.body;

  try {
    const auth = new google.auth.GoogleAuth({
      credentials: JSON.parse(process.env.GOOGLE_CREDENTIALS),
      scopes: ['https://www.googleapis.com/auth/calendar'],
    });

    const calendar = google.calendar({ version: "v3", auth });

    const event = {
      summary: title,
      start: { dateTime: startTime, timeZone: "UTC" },
      end: { 
        dateTime: new Date(new Date(startTime).getTime() + duration * 60000).toISOString(), 
        timeZone: "UTC" 
      },
    };

    const createdEvent = await calendar.events.insert({ 
      calendarId: "primary", 
      resource: event 
    });

    res.json({ eventLink: createdEvent.data.htmlLink });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


app.get("/", (req, res) => {
  res.send("IMG CRM HUB is Running 🚀");
});

app.post("/create-subdomain", async (req, res) => {
  const { clientName } = req.body;
  const subdomain = `crm-${uuidv4().slice(0, 5)}.imgcrmhub.com`;

  try {
    await db.collection("PublishedSites").add({
      clientName,
      subdomain,
      createdAt: new Date(),
    });

    res.json({ message: "CRM published!", subdomain });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/create-subdomain", async (req, res) => {
  if (!client) {
    return res.status(503).json({ error: "MongoDB not configured" });
  }

  const { clientName } = req.body;
  const subdomain = `crm-${uuidv4().slice(0, 5)}.imgcrmhub.com`;

  try {
    await client.connect();
    const db = client.db("sample_mflix");
    await db.collection("CRMs").insertOne({
      clientName,
      subdomain,
      createdAt: new Date(),
    });
    await client.close();
    res.json({ message: "CRM published!", subdomain });
  } catch (error) {
    console.error("Error creating subdomain:", error);
    res.status(500).json({ error: error.message });
  }
});

app.post("/connect-domain", async (req, res) => {
  const { clientId, customDomain } = req.body;

  try {
    await client.connect();
    const db = client.db("sample_mflix");
    await db.collection("CRMs").updateOne(
      { _id: clientId },
      { $set: { customDomain } }
    );
    await client.close();
    res.json({ message: "Custom domain connected!", customDomain });
  } catch (error) {
    console.error("Error connecting custom domain:", error);
    res.status(500).json({ error: error.message });
  }
});


app.post("/set-role", async (req, res) => {
  const { userId, role } = req.body;

  try {
    await db.collection("Users").doc(userId).set({ role }, { merge: true });
    res.json({ message: "Role assigned!" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Handle React routing, return all requests to React app
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'client/build', 'index.html'));
});

app.post("/generate-section", async (req, res) => {
  const { prompt } = req.body;

  try {
    const response = await axios.post(
      "https://api.openai.com/v1/completions",
      {
        model: "gpt-4",
        prompt: `Generate clean, responsive HTML and CSS for: ${prompt}`,
        max_tokens: 300,
        temperature: 0.5,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    res.json({ code: response.data.choices[0].text });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});