import React, { useState } from "react";
import { Responsive, WidthProvider } from "react-grid-layout";
import Toolbar from "./Toolbar";
import StyleEditor from "./StyleEditor";

const ResponsiveGridLayout = WidthProvider(Responsive);

const WebflowEditor = () => {
  const [layout, setLayout] = useState([]);
  const [elements, setElements] = useState([]);
  const [selectedElement, setSelectedElement] = useState(null);

  const addElement = (type) => {
    setElements((prev) => [...prev, { id: `el-${prev.length}`, type }]);
  };

  const updateStyle = (styles) => {
    setElements((prev) =>
      prev.map((el) => (el.id === selectedElement ? { ...el, styles } : el))
    );
  };

  return (
    <div>
      <Toolbar addElement={addElement} />
      <h2>Webflow-Style CRM Editor</h2>
      {selectedElement && <StyleEditor selectedElement={selectedElement} updateStyle={updateStyle} />}
      <ResponsiveGridLayout
        className="layout"
        layouts={{ lg: layout }}
        breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
        cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
        rowHeight={30}
        width={1200}
        isResizable={true}
        onLayoutChange={(newLayout) => setLayout(newLayout)}
      >
        {elements.map((el, index) => (
          <div 
            key={el.id} 
            data-grid={{ x: 0, y: index * 2, w: 4, h: 2 }}
            onClick={() => setSelectedElement(el.id)}
            style={el.styles}
          >
            {el.type === "Heading" && <h2>Heading</h2>}
            {el.type === "Paragraph" && <p>This is a paragraph.</p>}
            {el.type === "Image" && <img src="https://via.placeholder.com/150" alt="Placeholder" />}
            {el.type === "Button" && <button>Click Me</button>}
            {el.type === "Video" && <video controls><source src="video.mp4" type="video/mp4" /></video>}
            {el.type === "Form" && <form><input type="text" placeholder="Your Name" /><button>Submit</button></form>}
          </div>
        ))}
      </ResponsiveGridLayout>
    </div>
  );
};

export default WebflowEditor;